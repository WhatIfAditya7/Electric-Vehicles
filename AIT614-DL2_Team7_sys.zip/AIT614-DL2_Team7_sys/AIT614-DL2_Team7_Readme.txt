Step 1: Go to https://community.cloud.databricks.com/login.html (Databricks Community Edition). Log in or sign up for the community edition.

Step 2: Go to Create-> Notebook -> File ->Import Notebook. Upload the Python file provided.

Step 3: Click Connect button -> Create New Resource -> Enter the cluster name (Team7 Project)
	->Click 'Create,Attach, & Run'.

Step 4: Go to File -> Upload data to DBFS -> Upload the dataset provided (https://catalog.data.gov/dataset/electric-vehicle-population-data)

Step 5: Go to Run in the menu -> Run All.

Step 6: For visualization, check the visualization tab beside the output table tab.